from setuptools import setup,find_packages


setup(
      author="chandim",
      author_email="chandimsett@gmail.com",
      packages=find_packages(),
      include_package_data=True,
      name='common_utils',
      version='0.0.1',
      description='prediction_service',
)